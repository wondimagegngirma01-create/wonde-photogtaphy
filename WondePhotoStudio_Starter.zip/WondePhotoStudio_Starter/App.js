import React, { useState } from 'react';
import { View, Text, TouchableOpacity, Image, ScrollView, Alert, ActivityIndicator, StyleSheet } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as ImageManipulator from 'expo-image-manipulator';
import * as MediaLibrary from 'expo-media-library';
import { StatusBar } from 'expo-status-bar';

const GOLD = '#D9B56D';
const BLACK = '#090909';

export default function App() {
  const [photo, setPhoto] = useState(null);
  const [busy, setBusy] = useState(false);

  async function pickPhoto() {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsEditing: true,
      quality: 1,
    });
    if (!result.canceled) setPhoto(result.assets[0].uri);
  }

  async function rotatePhoto() {
    if (!photo) return Alert.alert('Choose a photo first');
    setBusy(true);
    try {
      const result = await ImageManipulator.manipulateAsync(
        photo, [{ rotate: 90 }], { compress: 1, format: ImageManipulator.SaveFormat.PNG }
      );
      setPhoto(result.uri);
    } catch (e) {
      Alert.alert('Edit failed', String(e));
    } finally { setBusy(false); }
  }

  async function savePhoto() {
    if (!photo) return Alert.alert('Choose a photo first');
    const permission = await MediaLibrary.requestPermissionsAsync();
    if (!permission.granted) return Alert.alert('Permission required', 'Allow photo library access to save.');
    try {
      await MediaLibrary.saveToLibraryAsync(photo);
      Alert.alert('Saved', 'Photo saved to your gallery.');
    } catch (e) { Alert.alert('Save failed', String(e)); }
  }

  function aiNotice() {
    Alert.alert(
      'Online AI tools',
      'AI background removal and enhancement will be connected through a secure server. Do not add private API keys directly to this app.'
    );
  }

  return (
    <View style={styles.screen}>
      <StatusBar style="light" />
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.brand}>WONDE</Text>
        <Text style={styles.title}>PHOTO STUDIO</Text>
        <Text style={styles.subtitle}>Professional Photo Editor</Text>

        <View style={styles.preview}>
          {photo ? <Image source={{ uri: photo }} style={styles.photo} resizeMode="contain" />
            : <Text style={styles.placeholder}>Your photo will appear here</Text>}
        </View>

        <TouchableOpacity style={styles.primary} onPress={pickPhoto}>
          <Text style={styles.primaryText}>＋ Choose Photo</Text>
        </TouchableOpacity>

        <View style={styles.grid}>
          <Tool title="Rotate 90°" onPress={rotatePhoto}/>
          <Tool title="Save Photo" onPress={savePhoto}/>
          <Tool title="AI Enhance" onPress={aiNotice}/>
          <Tool title="Remove Background" onPress={aiNotice}/>
          <Tool title="Black Studio BG" onPress={aiNotice}/>
          <Tool title="Portrait Retouch" onPress={aiNotice}/>
        </View>

        {busy && <ActivityIndicator color={GOLD} />}
        <Text style={styles.footer}>Wonde Photography • Your Photos. Your Style.</Text>
      </ScrollView>
    </View>
  );
}

function Tool({ title, onPress }) {
  return (
    <TouchableOpacity style={styles.tool} onPress={onPress}>
      <Text style={styles.toolText}>{title}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  screen:{flex:1,backgroundColor:BLACK},
  content:{padding:20,alignItems:'center'},
  brand:{color:GOLD,fontSize:30,fontWeight:'900',letterSpacing:4,marginTop:20},
  title:{color:'#fff',fontSize:24,fontWeight:'800',letterSpacing:1},
  subtitle:{color:'#aaa',marginTop:5,marginBottom:20},
  preview:{width:'100%',height:300,borderColor:'#333',borderWidth:1,borderRadius:18,backgroundColor:'#171717',alignItems:'center',justifyContent:'center',overflow:'hidden'},
  photo:{width:'100%',height:'100%'},
  placeholder:{color:'#888'},
  primary:{backgroundColor:GOLD,padding:16,borderRadius:12,width:'100%',alignItems:'center',marginTop:16},
  primaryText:{color:'#111',fontWeight:'800',fontSize:16},
  grid:{width:'100%',flexDirection:'row',flexWrap:'wrap',justifyContent:'space-between',marginTop:12},
  tool:{width:'48%',padding:16,backgroundColor:'#202020',borderColor:'#3b3b3b',borderWidth:1,borderRadius:12,marginTop:10,alignItems:'center'},
  toolText:{color:'#fff',fontWeight:'600'},
  footer:{color:'#777',fontSize:12,marginTop:25,marginBottom:20}
});
