# WONDE PHOTO STUDIO — Starter App

This is a starter project for an Android photo editor using Expo / React Native.

## Included in this starter
- Home screen branded WONDE PHOTO STUDIO
- Pick a photo from device gallery
- Offline resize / rotate / crop-ready image processing via Expo Image Manipulator
- Save edited image to device gallery
- Online AI screen placeholder with secure-backend guidance

## Important
This is a starter project, NOT a finished Photoshop/AI app and does not yet generate a distributable APK.
AI services require a backend endpoint and API credentials. Never put private AI API keys in the mobile app.

## Build from an Android phone
1. Upload this project to a GitHub repository (or use a browser-based coding environment).
2. Use Expo's cloud build (EAS Build) to create an Android APK.
3. Follow Expo's current Android build instructions: https://docs.expo.dev/build/setup/
4. Install the APK on your Android device.

A computer is not required for cloud builds, but setup may be easier with a browser-based coding service.
